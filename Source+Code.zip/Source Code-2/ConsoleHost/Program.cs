﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MulServiceLibrary;
using System.ServiceModel;
using System.ServiceModel.Description;
namespace ConsoleHost
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri baseAddress = new Uri("http://localhost:6789");

            ServiceHost Sh = new ServiceHost(typeof(MulService), baseAddress);

            ServiceEndpoint Se = Sh.AddServiceEndpoint(typeof(IMulService), new WSHttpBinding(), baseAddress);

            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            Sh.Description.Behaviors.Add(smb);

            Sh.Open();

           
            Console.WriteLine("Started.....");
            Console.ReadLine();

            Sh.Close();
        }
    }
}
